import{f as e}from"./site-content-BkEmymUy.js";import{r as t}from"./photos-BW6EAMCN.js";import{t as n}from"./social-icon-CS2bHoaL.js";import{i as r,n as i,r as a}from"./pondok-ByAc9hJX.js";import{t as o}from"./form-submission-C4ijTKk7.js";function s(o={}){let s=e(o.tiktok);return`
    <!-- Page Header -->
    <section class="hero" style="min-height: 50vh">
      <div class="hero-bg" style="background-image: url('${t.hero.kontak}')"></div>
      <div class="hero-overlay"></div>
      <div class="hero-pattern"></div>
      <div class="hero-content">
        <span class="section-label" style="color: var(--green-300)">KONTAK</span>
        <h1 style="font-size: 44px">Hubungi Kami</h1>
        <p class="hero-subtitle">Kami siap menjawab pertanyaan Anda seputar pesantren, pendaftaran, dan program.</p>
      </div>
    </section>

    <!-- Contact Info + Form -->
    <section class="section" style="background: var(--neutral-50)">
      <div class="container">
        <div class="grid-2">
          <!-- Contact Info -->
          <div>
            <span class="section-label reveal">INFORMASI KONTAK</span>
            <h2 class="reveal reveal-delay-1" style="margin-bottom: var(--space-xl)">Jangan Ragu untuk Bertanya</h2>
            
            <div style="display:flex;flex-direction:column;gap:var(--space-lg)" class="reveal reveal-delay-2">
              <div style="display:flex;gap:var(--space-md);align-items:flex-start">
                <div class="card-icon" style="flex-shrink:0">
                  <i data-lucide="map-pin" style="width:22px;height:22px"></i>
                </div>
                <div>
                  <strong style="display:block;margin-bottom:4px">Alamat</strong>
                  <span style="color:var(--neutral-700);font-size:15px">${i.address}</span>
                </div>
              </div>
              <div style="display:flex;gap:var(--space-md);align-items:flex-start">
                <div class="card-icon" style="flex-shrink:0">
                  <i data-lucide="phone" style="width:22px;height:22px"></i>
                </div>
                <div>
                  <strong style="display:block;margin-bottom:4px">Telepon</strong>
                  <a class="contact-phone" href="tel:${i.telephone}">${i.phone}</a>
                </div>
              </div>
              <div style="display:flex;gap:var(--space-md);align-items:flex-start">
                <div class="card-icon" style="flex-shrink:0"><i data-lucide="message-circle" style="width:22px;height:22px"></i></div>
                <div><strong style="display:block;margin-bottom:4px">WhatsApp</strong><p class="contact-channel-help">Kirim pesan kepada pengurus pondok.</p>
                  <a href="https://wa.me/${i.whatsapp}?text=Assalamu'alaikum%2C%20saya%20ingin%20bertanya%20tentang%20Pesantren%20An-Nahl." target="_blank" rel="noopener" style="display:inline-flex;align-items:center;gap:6px;margin-top:8px;padding:8px 16px;background:#25D366;color:white;border-radius:var(--radius-sm);font-size:13px;font-weight:500;text-decoration:none;transition:all 0.3s ease">
                    <svg viewBox="0 0 32 32" width="16" height="16" fill="white"><path d="M16.004 0h-.008C7.174 0 0 7.176 0 16.004c0 3.5 1.128 6.744 3.046 9.378L1.054 31.29l6.118-1.958A15.914 15.914 0 0016.004 32C24.826 32 32 24.826 32 16.004 32 7.176 24.826 0 16.004 0zm9.31 22.606c-.39 1.1-1.932 2.014-3.164 2.28-.844.178-1.944.32-5.652-1.214-4.746-1.962-7.8-6.78-8.034-7.094-.226-.314-1.886-2.512-1.886-4.792 0-2.28 1.194-3.402 1.618-3.868.39-.428 1.028-.624 1.64-.624.198 0 .376.01.536.018.47.02.706.048 1.016.788.388.926 1.332 3.248 1.448 3.484.118.236.234.546.078.86-.148.32-.278.52-.518.796-.236.278-.496.62-.708.832-.236.236-.482.492-.208.964.276.47 1.226 2.022 2.632 3.274 1.81 1.612 3.334 2.112 3.806 2.348.47.236.748.198 1.024-.118.278-.32 1.194-1.388 1.512-1.866.314-.47.632-.394 1.064-.236.434.156 2.756 1.3 3.226 1.536.47.236.788.354.904.548.118.198.118 1.1-.272 2.198z"/></svg>
                    Chat via WhatsApp
                  </a>
                </div>
              </div>
              <div style="display:flex;gap:var(--space-md);align-items:flex-start">
                <div class="card-icon" style="flex-shrink:0">
                  <i data-lucide="mail" style="width:22px;height:22px"></i>
                </div>
                <div>
                  <strong style="display:block;margin-bottom:4px">Email</strong>
                  <a href="mailto:${i.email}" style="color:var(--neutral-700);font-size:15px;overflow-wrap:anywhere">${i.email}</a>
                </div>
              </div>
              <div style="display:flex;gap:var(--space-md);align-items:flex-start">
                <div class="card-icon" style="flex-shrink:0">
                  <i data-lucide="clock" style="width:22px;height:22px"></i>
                </div>
                <div>
                  <strong style="display:block;margin-bottom:4px">Jam Operasional</strong>
                  <span style="color:var(--neutral-700);font-size:15px">Senin – Jumat: 08:00 – 16:00 WIB<br>Sabtu: 08:00 – 12:00 WIB</span>
                </div>
              </div>
            </div>

            <!-- Social -->
            <div style="margin-top:var(--space-xl)" class="reveal reveal-delay-3">
              <strong style="display:block;margin-bottom:var(--space-md)">Media Sosial</strong>
              <div style="display:flex;gap:var(--space-sm)">
                <a href="https://www.instagram.com/annahl.official?vrfl=MmlweHloM2wzcWgw" style="width:44px;height:44px;display:flex;align-items:center;justify-content:center;border-radius:var(--radius-sm);background:var(--green-50);color:var(--green-700);transition:all 0.3s ease" onmouseover="this.style.background='var(--green-800)';this.style.color='white'" onmouseout="this.style.background='var(--green-50)';this.style.color='var(--green-700)'" target="_blank" rel="noopener noreferrer" aria-label="instagram">
                  ${n(`instagram`)}
                </a>
                <a href="https://www.facebook.com/share/1DjhtbZ3na/" style="width:44px;height:44px;display:flex;align-items:center;justify-content:center;border-radius:var(--radius-sm);background:var(--green-50);color:var(--green-700);transition:all 0.3s ease" onmouseover="this.style.background='var(--green-800)';this.style.color='white'" onmouseout="this.style.background='var(--green-50)';this.style.color='var(--green-700)'" target="_blank" rel="noopener noreferrer" aria-label="facebook">
                  ${n(`facebook`)}
                </a>
                <a href="https://youtube.com/@ppuan-nahl4784?si=iWzGJO98qyJwW8HN" style="width:44px;height:44px;display:flex;align-items:center;justify-content:center;border-radius:var(--radius-sm);background:var(--green-50);color:var(--green-700);transition:all 0.3s ease" onmouseover="this.style.background='var(--green-800)';this.style.color='white'" onmouseout="this.style.background='var(--green-50)';this.style.color='var(--green-700)'" target="_blank" rel="noopener noreferrer" aria-label="youtube">
                  ${n(`youtube`)}
                </a>
                ${s?`<a href="${s}" data-content-ignore class="contact-social-link" aria-label="TikTok" target="_blank" rel="noopener noreferrer">${n(`tiktok`)}</a>`:``}
              </div>
            </div>
          </div>

          <!-- Contact Form -->
          <div class="reveal">
            <div class="card" style="padding:var(--space-xl)">
              <h3 style="margin-bottom:var(--space-lg)">Kirim Pesan</h3>
              <form id="contact-form">
                <div class="form-group">
                  <label class="form-label">Nama Lengkap *</label>
                  <input id="contact-name" type="text" class="form-input" placeholder="Nama Anda" required />
                </div>
                <div style="display:grid;grid-template-columns:1fr 1fr;gap:var(--space-md)">
                  <div class="form-group">
                    <label class="form-label">Email *</label>
                    <input id="contact-email" type="email" class="form-input" placeholder="email@contoh.com" required />
                  </div>
                  <div class="form-group">
                    <label class="form-label">No. Telepon</label>
                    <input id="contact-phone" type="tel" class="form-input" placeholder="08xx-xxxx-xxxx" />
                  </div>
                </div>
                <div class="form-group">
                  <label class="form-label">Subjek *</label>
                  <select id="contact-subject" class="form-select" required>
                    <option value="">Pilih topik</option>
                    <option>Informasi Pendaftaran</option>
                    <option>Informasi Program</option>
                    <option>Kunjungan / Silaturahmi</option>
                    <option>Donasi</option>
                    <option>Lainnya</option>
                  </select>
                </div>
                <div class="form-group">
                  <label class="form-label">Pesan *</label>
                  <textarea id="contact-message" class="form-textarea" placeholder="Tuliskan pesan atau pertanyaan Anda..." required></textarea>
                </div>
                <button type="submit" class="btn btn-primary" style="width:100%">
                  <i data-lucide="send" style="width:18px;height:18px"></i>
                  Kirim Pesan
                </button>
              </form>
            </div>
          </div>
        </div>
      </div>
    </section>

    <!-- Google Maps -->
    <section style="background:var(--green-50);padding:var(--space-3xl) 0">
      <div class="container">
        <div class="section-header">
          <span class="section-label reveal">LOKASI</span>
          <h2 class="section-title reveal reveal-delay-1">Temukan Kami</h2>
        </div>
        <div class="reveal reveal-delay-2" style="border-radius:var(--radius-lg);overflow:hidden;box-shadow:var(--shadow-lg);height:400px">
          <iframe 
            src="${a}"
            title="Lokasi Pondok Pesantren An-Nahl di Gunung Picung, Pamijahan, Bogor"
            width="100%" 
            height="100%" 
            style="border:0" 
            allowfullscreen="" 
            loading="lazy" 
            referrerpolicy="no-referrer-when-downgrade">
          </iframe>
        </div>
        <div class="contact-map-link"><a href="${r}" class="btn btn-secondary" target="_blank" rel="noopener noreferrer">Buka di Google Maps →</a></div>
      </div>
    </section>
  `}window.initKontak=function(){o(document.getElementById(`contact-form`),`kontak`,()=>({nama:document.getElementById(`contact-name`).value.trim(),email:document.getElementById(`contact-email`).value.trim(),telepon:document.getElementById(`contact-phone`).value.trim(),subjek:document.getElementById(`contact-subject`).value,pesan:document.getElementById(`contact-message`).value.trim()}),`Pesan diterima. Pengurus akan merespons melalui kontak yang Anda cantumkan.`)};export{s as Kontak};