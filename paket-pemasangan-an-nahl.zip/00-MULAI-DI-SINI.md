# Mulai di sini — paket pemasangan An-Nahl

Paket ini disiapkan untuk pemasangan manual. Hosting, izin Google baru,
folder lampiran, endpoint Google, dan migrasi pembatasan Supabase belum diaktifkan.
Paket tidak berisi kunci privat. Semua file pada CHECKSUMS.sha256 dapat diperiksa.

## Isi paket

1. 01-public_html.zip — isi website yang sudah dibangun dan penghubung PHP.
2. 02-google-apps-script/ — Code.gs dan appsscript.json untuk akun pondok.
3. 03-contoh-konfigurasi-privat/ — contoh saja, tanpa kunci asli.
4. 04-supabase/ — migrasi pembatasan formulir Supabase menjadi kontak saja.
5. PANDUAN-LENGKAP.md — langkah dan pemeriksaan lengkap.

## Urutan pemasangan

1. Simpan backup website sebelum mengganti file di Hostinger. Pastikan website
   PHP/HTML dengan PHP 8.1+ dan cURL; paket ini tidak ditujukan untuk Website Builder.
2. Masuk ke akun pondokpemberdayaanannahl@gmail.com. Buka Sheet rekap pondok,
   lalu Extensions → Apps Script. Pasang kedua file dari 02-google-apps-script.
3. Pertahankan properti ANNAHL_SPREADSHEET_ID dan ANNAHL_SHEETS_SECRET yang
   sudah diisi. Pemilik perlu meninjau izin Google baru sebelum menjalankan setup.
4. Jalankan setupGoogleForms, kemudian checkGoogleFormsSetup. Folder Drive
   lampiran dibuat privat pada akun pondok. Tidak diperlukan trigger lima menit.
5. Deploy sebagai Web app yang berjalan sebagai akun pondok. Hosting harus dapat
   menjangkau endpoint. Kode tetap mensyaratkan tanda tangan server pada setiap kiriman.
6. Salin URL deployment berakhiran /exec ke apps_script_url dalam konfigurasi PHP
   privat. File privat yang sudah berisi kunci disiapkan terpisah di komputer proyek,
   bukan di ZIP ini. Jika memakai contoh, isi kunci yang sama dengan properti Google.
7. Letakkan konfigurasi asli pada annahl-private/forms-config.php DI LUAR public_html.
   Jangan mengunggah konfigurasi asli ke folder publik atau memasukkannya ke Git.
8. Ekstrak ISI 01-public_html.zip ke public_html. Jangan menaruh paket induk ini
   sebagai isi website. File api/forms.php harus berada di public_html/api/forms.php.
9. Setelah jalur Google siap dan rilis formulir dipasang, terapkan migrasi di
   04-supabase melalui SQL Editor proyek yang benar. Migrasi tidak menghapus data.
10. Uji satu pendaftaran dan satu konfirmasi donasi dengan data rekaan, foto/PDF,
    lalu coba kirim ulang. Pastikan hanya ada satu baris dan berkas tetap utuh,
    milik akun pondok, serta privat. Bersihkan hanya data uji yang sengaja dibuat.

## Hasil yang diharapkan

- Isian pendaftaran/donasi tersimpan di Google Sheets, lampiran di Google Drive pondok.
- Sheet menyediakan tautan lampiran. Status tindak lanjut diubah di Sheet.
- Supabase tetap dipakai untuk berita, galeri editorial, login pengurus, dan kontak.
- Jika konfigurasi Google belum lengkap, formulir menampilkan pesan belum siap.
  Menyalin paket publik saja tidak otomatis mengaktifkan penyimpanan Google.

Lampiran: maksimal 3 file, 2 MB per file, 5 MB total. Format JPG/JPEG, PNG, WebP,
PDF, DOCX, XLSX, PPTX. Konfirmasi donasi tidak membuktikan transfer bank sudah masuk.